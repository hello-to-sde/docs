---
name: my-writing
description: Write emails, messages and posts in my voice. Use whenever I ask for an email, message, reply or post.
---

# Rules
- Point in the first line. Max 5 short sentences.
- Never write: "I hope this email finds you well", "delve", "I'm excited to".
- No long dashes. No emoji.
- Manager: polite, direct. Friends: casual.
- Sign off: "Thanks," and my name.

# How I really write (copy the style, not the content)
Example 1 (to my manager):
<paste a short email you really wrote to your manager>

Example 2 (to a friend or colleague):
<paste a short message you really wrote to a friend or colleague>
